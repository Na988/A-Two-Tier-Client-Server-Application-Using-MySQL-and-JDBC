
package project3javaguidb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JLabel;

public class ConnectionEstablisherForDatabase {

    Connection connection;
    public  Connection createConnectionForOperationsCount(String driver,String url,String user,String pass) {
        try {
            String urlForConnectionDatabase = url;
           
            String userOfDatabase=user;
            String passwordOfDatabase = pass;
            Class.forName(driver);
             connection = DriverManager.getConnection(urlForConnectionDatabase, userOfDatabase, passwordOfDatabase);
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            
            return null; 
        }
    }

    public  Connection currentConnectionWithDatabse(JLabel showConnectionResult,String driver,String url ,String userName , String passDatabase) {
        try {
            String usrlForConnectionDatabase = url;
            showConnectionResult.setText("CONNECTED TO:"+usrlForConnectionDatabase);
            Class.forName(driver);
            connection = DriverManager.getConnection(usrlForConnectionDatabase, userName, passDatabase);
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            
            
            showConnectionResult.setText("NOT CONNECTED! User Credentials Do Not Match Properties File!");
            
            return null; 
        }
    }

    
    
    
   
    
    
    
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

