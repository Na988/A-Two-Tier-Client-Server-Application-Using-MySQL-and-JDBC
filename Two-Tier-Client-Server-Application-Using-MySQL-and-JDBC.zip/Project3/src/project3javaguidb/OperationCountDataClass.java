
package project3javaguidb;


public class OperationCountDataClass {
    private String nameOfUser;
    private int totalQuries;
    private int allValidQuries;

    public OperationCountDataClass(String nameOfUser, int totalQuires, int allValidQuries) {
        this.nameOfUser = nameOfUser;
        this.totalQuries = totalQuires;
        this.allValidQuries = allValidQuries;
    }

    public String getNameOfUser() {
        return nameOfUser;
    }

    public void setNameOfUser(String nameOfUser) {
        this.nameOfUser = nameOfUser;
    }

    public int getTotalQuries() {
        return totalQuries;
    }

    public void setTotalQuries(int totallQuries) {
        this.totalQuries = totallQuries;
    }

    public int getAllValidQuries() {
        return allValidQuries;
    }

    public void setAllValidQuries(int allValidQuries) {
        this.allValidQuries = allValidQuries;
    }
    
}
