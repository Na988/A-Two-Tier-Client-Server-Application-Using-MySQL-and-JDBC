
package project3javaguidb;
import java.util.ArrayList;
import java.util.List;

public class StoreDisplayTableData {
    private List<String> databaseTableColumnsNames;
    private List<String[]> tableDataHolder;

    public StoreDisplayTableData() {
        databaseTableColumnsNames = new ArrayList<>();
        tableDataHolder = new ArrayList<>();
    }

    public List<String> getColNames() {
        return databaseTableColumnsNames;
    }

    public void getDatabaseTableData(String columnName) {
        databaseTableColumnsNames.add(columnName);
    }

    public List<String[]> getMyAllTableData() {
        return tableDataHolder;
    }

    public void addRowDatabse(String[] rowData) {
        tableDataHolder.add(rowData);
    }
    
    
    
}
