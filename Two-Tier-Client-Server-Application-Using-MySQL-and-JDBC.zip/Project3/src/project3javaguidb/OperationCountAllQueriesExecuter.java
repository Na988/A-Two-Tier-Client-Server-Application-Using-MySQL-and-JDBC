
package project3javaguidb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OperationCountAllQueriesExecuter {
    private Connection connectionOfDatabase;

    public OperationCountAllQueriesExecuter(Connection databaseConnections) {
        this.connectionOfDatabase = databaseConnections;
    }

    public boolean insert(OperationCountDataClass operationsCount) throws SQLException {
        
        String query = "INSERT INTO operationscount (login_username, num_queries, num_updates) VALUES (?, ?, ?)";
        PreparedStatement PerparedStatement = connectionOfDatabase.prepareStatement(query);
        PerparedStatement.setString(1, operationsCount.getNameOfUser());
        PerparedStatement.setInt(2, operationsCount.getTotalQuries());
        PerparedStatement.setInt(3, operationsCount.getAllValidQuries());

        boolean rowInserteds = PerparedStatement.executeUpdate() > 0;
        PerparedStatement.close();
        
        return rowInserteds;
    }

    public OperationCountDataClass get(String login_username) throws SQLException {
        String selectSQL = "SELECT * FROM operationscount WHERE login_username = ?";
        PreparedStatement statement = connectionOfDatabase.prepareStatement(selectSQL);
        statement.setString(1, login_username);

        ResultSet resultSet = statement.executeQuery();

        OperationCountDataClass operationsCount = null;
        if (resultSet.next()) {
            operationsCount = new OperationCountDataClass(
                resultSet.getString("login_username"),
                resultSet.getInt("num_queries"),
                resultSet.getInt("num_updates")
            );
        }

        resultSet.close();
        statement.close();
        
        return operationsCount;
    }

    public boolean update(OperationCountDataClass operationsCount) throws SQLException {
        String updateSQL = "UPDATE operationscount SET num_queries = ?, num_updates = ? WHERE login_username = ?";
        PreparedStatement statement = connectionOfDatabase.prepareStatement(updateSQL);
        statement.setInt(1, operationsCount.getTotalQuries());
        statement.setInt(2, operationsCount.getAllValidQuries());
        statement.setString(3, operationsCount.getNameOfUser());

        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();
        
        
        return rowUpdated;
    }

    public boolean delete(String login_username) throws SQLException {
        String deleteSQL = "DELETE FROM operationscount WHERE login_username = ?";
        PreparedStatement statement = connectionOfDatabase.prepareStatement(deleteSQL);
        statement.setString(1, login_username);

        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        
        return rowDeleted;
    }
    
    
    
    
    
    public ArrayList<OperationCountDataClass> getAllOperationsCounts() throws SQLException {
    String selectAllSQL = "SELECT * FROM operationscount";
    ArrayList<OperationCountDataClass> operationsCounts = new ArrayList<>();

    try (ResultSet resultSet = connectionOfDatabase.createStatement().executeQuery(selectAllSQL)) {
        while (resultSet.next()) {
            String login_username = resultSet.getString("login_username");
            int num_query = resultSet.getInt("num_queries");
            int num_update = resultSet.getInt("num_updates");

            OperationCountDataClass operationsCount = new OperationCountDataClass(login_username, num_query, num_update);
            operationsCounts.add(operationsCount);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } 

    return operationsCounts;
}
    
    
    
    
}

