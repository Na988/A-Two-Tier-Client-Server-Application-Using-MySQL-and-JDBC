
package project3javaguidb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MysqlQueryExecuter {
    private Connection databaseConnection;

    public MysqlQueryExecuter(Connection dbConnection) {
        this.databaseConnection = dbConnection;
    }

    public StoreDisplayTableData getAllMyTableData(String userQueryToDatabase) throws SQLException {
        StoreDisplayTableData allMyTableData = new StoreDisplayTableData();

        try (PreparedStatement statement = databaseConnection.prepareStatement(userQueryToDatabase);
             ResultSet resultSet = statement.executeQuery()) {
            ResultSetMetaData resultData = resultSet.getMetaData();
            int columnCount = resultData.getColumnCount();

        
            for (int currentIndex = 1; currentIndex <= columnCount; currentIndex++) {
                allMyTableData.getDatabaseTableData(resultData.getColumnName(currentIndex));
            }

            while (resultSet.next()) {
                String[] rowData = new String[columnCount];
                for (int currentIndex = 1; currentIndex <= columnCount; currentIndex++) {
                    rowData[currentIndex - 1] = resultSet.getString(currentIndex);
                }
                allMyTableData.addRowDatabse(rowData);
            }
        }

        return allMyTableData;
    }
    
    
    
    public void queryForNoneReturnData(String databaseQuery)  {
        
        try {
            StoreDisplayTableData allMyData = new StoreDisplayTableData();
            
            PreparedStatement runStatement = databaseConnection.prepareStatement(databaseQuery);
            int resultSet = runStatement.executeUpdate();
                    
              JOptionPane.showMessageDialog(null, "Successfully Updated... 1 row update !");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ""+ex.getMessage());
            
            
        }
        
        
        
        
    }
    
    
    
    
    
}
